<?php

namespace PauliusMacernis\PlayingWithLaravelAndDockerPrivatePackage;
/**
 * An example class demonstrating installing a private
 * Composer package in Docker
 */
class Example
{
}